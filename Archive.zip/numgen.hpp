#pragma once

#include "numgen.cpp"

inline int roll(int, int);
inline std::vector<std::vector<int>> diceset(std::vector<int>, std::vector<int>);